from __future__ import unicode_literals
import sys

from clld.scripts.util import initializedb, Data
from clld.db.meta import DBSession
from clld.db.models import common

import lotw_dev
from lotw_dev import models

import sqlite3

def main(args):
    data = Data()
    lotw_conn = sqlite3.connect("lotw_base.sqlite")
    lotw_base = lotw_conn.cursor()
    contrib = common.Contribution(id="initial_contrib",
                                  name="Initial contribution")


    dataset = common.Dataset(id=lotw_dev.__name__,
                             domain='lotw_dev.clld.org')
    DBSession.add(dataset)
    feature_dict = {}
    for feature in lotw_base.execute("SELECT * FROM Feature"):
        feature_dict[feature[0]] = common.Parameter(id=feature[0],
                                             name=feature[4])
    langs = lotw_base.execute("SELECT * FROM Language")
    for language in langs.fetchall():
        value_sets = []
        geodata = lotw_base.execute("SELECT * FROM Geographical_index WHERE Lang_id=?", str(language[0])).fetchone()
        data.add(common.Language, language[0],
                 id=str(language[0]),
                 name=language[3],
                 latitude=geodata[5],
                 longitude=geodata[6])
        # Lang_id=language["Lang_id"], Order_of_addition=language["Order_of_addition"],
                # Sorting_number=language["Sorting_number"], Code_ISO_639_3=language["Code_ISO_639_3"]
        language_features = lotw_base.execute("SELECT * FROM Binary_data WHERE Lang_id=?", str(language[0]))
        for l_feat in language_features.fetchall():
            feat_id = str(language[3])+"_"+str(l_feat[2])
            vs = common.ValueSet(id=feat_id,
                                 language=data["Language"][language[0]],
                                 parameter=feature_dict[l_feat[2]],
                                 contribution=contrib)
            DBSession.add(common.Value(id=feat_id,
                                       name=str(bool(l_feat[3])),
                                       valueset=vs))

    lotw_conn.close()




def prime_cache(args):
    """If data needs to be denormalized for lookup, do that here.
    This procedure should be separate from the db initialization, because
    it will have to be run periodiucally whenever data has been updated.
    """


if __name__ == '__main__':
    initializedb(create=main, prime_cache=prime_cache)
    sys.exit(0)
