from clldfabric import tasks
tasks.init('lotw_dev')
